# OFERTA A4 — 安卓超市特价纸生成器

一款原生 Java Android App。**扫码 → Open Food Facts 获取商品名/品牌 → 输入原价和优惠价 → 设置份数 → 拼 A4 → PDF 或直接打印**。

## 核心特点
- Google ML Kit Code Scanner：扫描 EAN-13/EAN-8/UPC 等条码；Google Play 服务提供扫码界面，无需应用自身请求相机权限。
- Open Food Facts API v3：通过条码自动填充西语商品名、品牌、规格；查不到可手动填写。无 API Key。
- 8 种纯黑白横版 OFERTA 样式（底色以黑/白为主，适合单色打印）。
- 4 个独立百分比滑块：OFERTA、商品名称、原价、特价价格；调整后在界面预览，导出 PDF 采用同一字号。
- 原价横线、特价数字巨大加粗。为避免文本裁切，价格文字太长时会自动适配宽度和高度。
- 每个商品独立填写重复打印份数（1-99），按添加顺序拼版：商品 A × 2 + B × 1 + C × 1 = 同一页 A4 的 4 张。
- A4 横向（PDF 842×595 pt），2×2，每张纸裁剪后约 148.5×105 mm，带中心裁剪虚线；不足 4 张的最后一页留空。
- 直接打印 Android PrintManager 或通过系统文件选择器保存 PDF。
- 打印队列、重复份数、字体倍率自动保存到手机本地，不需要登录。

## 用 GitHub Actions 免费编译 APK
1. 打开 https://github.com/new，仓库建议名称：`OfertaA4-Android`，新建 Public 或 Private 仓库。
2. 下载本项目源码 ZIP，**解压后**把 `app/`、`.github/`、`build.gradle`、`settings.gradle`、`gradle.properties`、`README.md` 等文件上传到新仓库根目录。不要直接上传 ZIP 文件当源码。
3. 在仓库的 **Actions** 选项卡运行 **Build Android APK** → **Run workflow**（也可直接 push 到 `main`/`master` 自动触发）。
4. 完成后打开该次任务最下方的 Artifacts，下载 `OfertaA4-debug-apk.zip`，解压得到 `app-debug.apk`，安装到 Android 手机。
5. 如仓库页面显示 Actions 未启用，请到 Settings → Actions → General 允许 GitHub Actions。

此 App 使用无需签名密钥的 **debug APK** 编译方式，直接用于自己手机测试；发布到 Play 商店需要自己配置 release signing。

## 环境
- Android 6.0+（minSdk 23）；有 Google Play Services 才能使用扫码窗口，手工输入仍然可用。
- 网络只用于查询商品，已有缓存或手工输入在离线状态也可生成 PDF。
- Gradle 8.11.1；Android Gradle Plugin 8.9.2；Java 17；compileSdk 35。

## Open Food Facts 使用注意
- 主要查询 `https://world.openfoodfacts.org/api/v3/product/{barcode}`。
- 官方产品读取限制 15 次/分钟/IP；App 优先本地缓存并进行查询节流。数据库并非覆盖所有阿根廷商品，内容也可能不完整，需要人工确认。
- 官方建议自定义 User-Agent，生产使用前请在 `MainActivity.java` 把 `OfertaA4/1.0 (Android personal supermarket label app)` 中的括号部分替换为你自己的真实联系网址或邮箱，遵守 Open Database License 及数据库归属和共享条件。
- 商品来自 Open Food Facts 社区数据： https://world.openfoodfacts.org ，建议应用内标注来源。

## 打印建议
- PDF 标准尺寸为 A4 横向。打印时选 **实际大小 100%**，关闭“适合纸张”缩放。
- 普通打印机可能不支持真正无边距；本 App 每张优惠纸内有安全边距，实际物理裁剪线为纵横中线。
- 若优惠价格非常长，自动适配宽度，以免裁切；调整百分比时请核对实时预览。

## 官方文档
- https://developers.google.com/ml-kit/vision/barcode-scanning/code-scanner
- https://openfoodfacts.github.io/openfoodfacts-server/api/
- https://developer.android.com/reference/android/graphics/pdf/PdfDocument
- https://developer.android.com/training/printing/custom-docs
