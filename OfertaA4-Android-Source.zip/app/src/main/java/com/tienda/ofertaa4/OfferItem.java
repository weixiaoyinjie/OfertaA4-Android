package com.tienda.ofertaa4;

public final class OfferItem {
    public final String barcode;
    public final String name;
    public final String brand;
    public final String before;
    public final String now;
    public final int style;
    public int copies;

    public OfferItem(String barcode, String name, String brand, String before, String now, int copies, int style) {
        this.barcode = barcode;
        this.name = name;
        this.brand = brand;
        this.before = before;
        this.now = now;
        this.copies = copies;
        this.style = style;
    }
}
