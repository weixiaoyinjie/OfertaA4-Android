package com.tienda.ofertaa4;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintDocumentInfo;
import android.print.PrintManager;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.common.api.ApiException;
import com.google.mlkit.vision.barcode.common.Barcode;
import com.google.mlkit.vision.codescanner.GmsBarcodeScanner;
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions;
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.ArrayList;
import java.util.List;
import java.util.HashMap;
import java.util.Map;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int CREATE_PDF_REQUEST=102;
    private static final int INK=Color.BLACK;
    private static final int BORDER=0xffd0d0d0;
    private final List<OfferItem> queue = new ArrayList<>();
    private final Map<String,SeekBar> fontSeekBars=new HashMap<>();
    private final ExecutorService io=Executors.newSingleThreadExecutor();
    private final Handler ui=new Handler(Looper.getMainLooper());
    private OfferRenderer.Fonts fonts=new OfferRenderer.Fonts();
    private SharedPreferences prefs;
    private EditText barcodeInput,nameInput,brandInput,oldInput,nowInput,copiesInput;
    private Spinner styleSpinner;
    private LinearLayout queueLayout;
    private TextView status,queueStats;
    private PreviewView preview;
    private PagePreviewView pagePreview;
    private ScrollView scroller;
    private byte[] pendingPdf;
    private long lastNetworkAt=0;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs=getSharedPreferences("oferta-a4-v1",MODE_PRIVATE);
        fonts.headline=prefs.getInt("font_headline",100);
        fonts.product=prefs.getInt("font_product",100);
        fonts.original=prefs.getInt("font_original",100);
        fonts.special=prefs.getInt("font_special",100);
        loadQueue();
        createUi();
        updateQueue();
    }

    private void createUi() {
        fontSeekBars.clear();
        ScrollView sc=new ScrollView(this);scroller=sc;sc.setFillViewport(true);
        LinearLayout root=new LinearLayout(this);root.setPadding(dp(15),dp(18),dp(15),dp(30));
        root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.WHITE);
        sc.addView(root);setContentView(sc);
        TextView title=text("OFERTA A4",29,true);root.addView(title);
        root.addView(text("黑白横版特价纸｜一张 A4 四格｜自动按商品份数拼页",13,false));
        space(root,14);
        root.addView(section("① 扫描条形码 / 查询商品"));
        barcodeInput=field("条形码：EAN-8 / EAN-13 / UPC",InputType.TYPE_CLASS_NUMBER);
        root.addView(barcodeInput);
        LinearLayout scanRow=row();
        Button scan=button("扫码",true), lookup=button("查询名称和品牌",false);
        scanRow.addView(scan,weight());scanRow.addView(lookup,weight());root.addView(scanRow);
        scan.setOnClickListener(v->scanBarcode());lookup.setOnClickListener(v->fetchProduct());
        status=text("扫码后从 Open Food Facts 查询；查不到也可以手动填写。",12,false);
        status.setTextColor(0xff555555);root.addView(status);
        space(root,14);
        root.addView(section("② 商品与价格"));
        nameInput=field("商品名称（可修改）",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        brandInput=field("品牌（可选）",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        oldInput=field("原价 ANTES，例如 3.500",InputType.TYPE_CLASS_TEXT);
        nowInput=field("优惠价 AHORA，例如 2.790",InputType.TYPE_CLASS_TEXT);
        root.addView(nameInput);root.addView(brandInput);root.addView(oldInput);root.addView(nowInput);
        root.addView(text("促销样式",14,true));
        String[] styles={"01 · OFERTA 黑色横幅","02 · ¡SUPER OFERTA!","03 · PRECIO ESPECIAL",
                "04 · OFERTA 黑框","05 · GRAN OFERTA","06 · REBAJA",
                "07 · ¡OFERTÓN!","08 · OFERTA DEL DÍA"};
        styleSpinner=new Spinner(this);
        ArrayAdapter<String> adapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,styles);
        styleSpinner.setAdapter(adapter);root.addView(styleSpinner);
        styleSpinner.setSelection(Math.max(0,Math.min(7,prefs.getInt("last_style",0))));
        root.addView(text("这款商品需要打印几张？",14,true));
        copiesInput=field("份数（1—99）",InputType.TYPE_CLASS_NUMBER);copiesInput.setText("1");root.addView(copiesInput);
        Button add=button("＋ 添加到打印清单",true);root.addView(add);add.setOnClickListener(v->addOffer());
        space(root,14);
        root.addView(section("③ 手动放大 / 缩小打印字体"));
        root.addView(text("分别调节标题、商品名、原价和特价数字。数字过长时会自动缩小避免截断。",12,false));
        root.addView(slider("OFERTA / 促销标题", "font_headline",60,160,fonts.headline,x->fonts.headline=x));
        root.addView(slider("商品名称", "font_product",60,160,fonts.product,x->fonts.product=x));
        root.addView(slider("原价 ANTES", "font_original",60,160,fonts.original,x->fonts.original=x));
        root.addView(slider("特价数字 AHORA", "font_special",60,170,fonts.special,x->fonts.special=x));
        Button reset=button("恢复默认字体 100%",false);root.addView(reset);
        reset.setOnClickListener(v->{
            for(SeekBar bar:fontSeekBars.values())bar.setProgress(100-60);
            toast("字号已恢复至 100%");
        });
        space(root,10);
        root.addView(section("④ 实时打印预览（单张）"));
        preview=new PreviewView();root.addView(preview,new LinearLayout.LayoutParams(-1,dp(225)));
        root.addView(text("预览与 PDF 使用同一排版；A4 页面中每张横向 14.85 × 10.5 厘米。",12,false));
        space(root,15);
        root.addView(section("⑤ 打印清单：自动混排"));
        queueStats=text("",14,true);root.addView(queueStats);
        root.addView(text("A4 第一页拼版预览（2 × 2）",12,false));
        pagePreview=new PagePreviewView();root.addView(pagePreview,new LinearLayout.LayoutParams(-1,dp(245)));
        queueLayout=new LinearLayout(this);queueLayout.setOrientation(LinearLayout.VERTICAL);root.addView(queueLayout);
        LinearLayout actionRow=row();
        Button save=button("导出 A4 PDF",true),print=button("直接打印",true);
        actionRow.addView(save,weight());actionRow.addView(print,weight());root.addView(actionRow);
        save.setOnClickListener(v->savePdf());print.setOnClickListener(v->printPdf());
        Button clear=button("清空打印清单",false);root.addView(clear);
        clear.setOnClickListener(v->new AlertDialog.Builder(this).setMessage("确定清空全部特价纸吗？")
                .setNegativeButton("取消",(d,w)->{}).setPositiveButton("清空",(d,w)->{queue.clear();persistQueue();updateQueue();}).show());
        root.addView(text("商品数据来源：Open Food Facts 社区数据库，名称、品牌和规格请核实。",11,false));
        root.addView(text("示例：牛奶 ×2 + 饼干 ×1 + 饮料 ×1 = 同一张 A4 的四格。\n打印机请选择 A4、横向、100% 实际尺寸；打印机不支持无边距时，边缘可能略有留白。",12,false));
        attachPreviewListener(nameInput);attachPreviewListener(brandInput);attachPreviewListener(oldInput);
        attachPreviewListener(nowInput);
        styleSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(android.widget.AdapterView<?> parent,View view,int position,long id){
                prefs.edit().putInt("last_style",position).apply();if(preview!=null)preview.invalidate();
            }
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent){}
        });
    }

    private interface FontSetter {void set(int n);}
    private LinearLayout slider(String caption,String key,int min,int max,int initial,FontSetter setter) {
        LinearLayout holder=new LinearLayout(this);holder.setOrientation(LinearLayout.VERTICAL);
        TextView label=text(caption+"  ·  "+initial+"%",13,true);holder.addView(label);
        SeekBar seek=new SeekBar(this);seek.setMax(max-min);seek.setProgress(Math.max(0,Math.min(max-min,initial-min)));
        holder.addView(seek);fontSeekBars.put(key,seek);seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb,int n,boolean user){
                int value=n+min; setter.set(value);label.setText(caption+"  ·  "+value+"%");
                if(preview!=null)preview.invalidate();
                if(pagePreview!=null)pagePreview.invalidate();
                prefs.edit().putInt(key,value).apply();
            }
            @Override public void onStartTrackingTouch(SeekBar s){}
            @Override public void onStopTrackingTouch(SeekBar s){}
        });
        return holder;
    }
    private void attachPreviewListener(EditText edit) {edit.addTextChangedListener(new TextWatcher(){
        @Override public void beforeTextChanged(CharSequence s,int a,int c,int f){}
        @Override public void onTextChanged(CharSequence s,int start,int before,int count){if(preview!=null)preview.invalidate();}
        @Override public void afterTextChanged(Editable e){}
    });}

    private OfferItem sampleOffer() {
        String name=trim(nameInput), brand=trim(brandInput),old=trim(oldInput),now=trim(nowInput);
        if(name.isEmpty())name="NOMBRE DEL PRODUCTO";
        if(old.isEmpty())old="3.500";
        if(now.isEmpty())now="2.790";
        return new OfferItem(trim(barcodeInput),name,brand,old,now,1,styleSpinner.getSelectedItemPosition()+1);
    }

    private void addOffer() {
        String name=trim(nameInput),old=normalizePrice(trim(oldInput)),now=normalizePrice(trim(nowInput));
        if(name.isEmpty()) {nameInput.setError("请输入商品名称");nameInput.requestFocus();return;}
        if(old==null || now==null) {toast("请输入正确的原价和优惠价，例如 3500 或 3.500,50");return;}
        BigDecimal o=parsePrice(old),n=parsePrice(now);
        if(o==null||n==null||o.signum()<=0||n.signum()<=0){toast("价格必须大于 0");return;}
        if(n.compareTo(o)>0){toast("优惠价不能高于原价");return;}
        int copies;
        try{copies=Integer.parseInt(trim(copiesInput));}catch(Exception e){copies=0;}
        if(copies<1||copies>99){copiesInput.setError("份数为 1—99");return;}
        queue.add(new OfferItem(trim(barcodeInput),name,trim(brandInput),old,now,copies,
                styleSpinner.getSelectedItemPosition()+1));
        persistQueue();updateQueue();toast("已加入 " + copies + " 张，合计 " + sheetCount() + " 张");
        // Keep the latest style and font choices; reset the data for the next barcode.
        barcodeInput.setText("");nameInput.setText("");brandInput.setText("");
        oldInput.setText("");nowInput.setText("");copiesInput.setText("1");
        status.setText("可以继续扫码添加下一个商品。 ");
    }

    private int sheetCount(){int n=0;for(OfferItem i:queue)n+=i.copies;return n;}
    private void updateQueue(){
        if(queueStats==null||queueLayout==null)return;
        int count=sheetCount();int pages=(count+3)/4;
        queueStats.setText("商品 " + queue.size()+" 种｜共 "+count+" 张｜A4 "+pages+" 页"+
                (count>0&&count%4!=0?"｜最后一页空 "+(4-count%4)+" 格":""));
        queueLayout.removeAllViews();
        if(pagePreview!=null)pagePreview.invalidate();
        for(int index=0;index<queue.size();index++){
            OfferItem item=queue.get(index);final int at=index;
            LinearLayout block=new LinearLayout(this);block.setPadding(dp(8),dp(8),dp(8),dp(8));
            block.setOrientation(LinearLayout.VERTICAL);
            TextView t=text((index+1)+". "+item.name+"  "+OfferRenderer.money(item.now),14,true);
            block.addView(t);block.addView(text("样式 "+item.style+"  ·  "+OfferRenderer.money(item.before)+" → "+OfferRenderer.money(item.now),12,false));
            LinearLayout controls=row();
            TextView qty=text("份数 "+item.copies+" 张",13,true);controls.addView(qty,weight());
            Button minus=button("－",false),plus=button("＋",false),edit=button("编辑",false),delete=button("删除",false);
            controls.addView(minus);controls.addView(plus);controls.addView(edit);controls.addView(delete);block.addView(controls);
            minus.setOnClickListener(v->{if(item.copies>1){item.copies--;persistQueue();updateQueue();}});
            plus.setOnClickListener(v->{if(item.copies<99){item.copies++;persistQueue();updateQueue();}});
            edit.setOnClickListener(v->{
                barcodeInput.setText(item.barcode);nameInput.setText(item.name);brandInput.setText(item.brand);
                oldInput.setText(item.before);nowInput.setText(item.now);copiesInput.setText(String.valueOf(item.copies));
                styleSpinner.setSelection(item.style-1);
                queue.remove(at);persistQueue();updateQueue();
                status.setText("已载入待修改商品；修改后请再次点击添加到打印清单。");
                if(scroller!=null)scroller.smoothScrollTo(0,0);
            });
            delete.setOnClickListener(v->{queue.remove(at);persistQueue();updateQueue();});
            View hr=new View(this);hr.setBackgroundColor(BORDER);
            queueLayout.addView(block);queueLayout.addView(hr,new LinearLayout.LayoutParams(-1,dp(1)));
        }
    }

    private byte[] createPdfOrNotify(){
        if(queue.isEmpty()){toast("打印清单为空，请先添加商品");return null;}
        try{return OfferRenderer.pdf(new ArrayList<>(queue),fonts.copy());}
        catch(Exception ex){toast("生成 PDF 失败："+ex.getMessage());return null;}
    }
    private void savePdf(){
        pendingPdf=createPdfOrNotify();if(pendingPdf==null)return;
        Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/pdf");
        intent.putExtra(Intent.EXTRA_TITLE,"OFERTA_A4_"+System.currentTimeMillis()+".pdf");
        startActivityForResult(intent,CREATE_PDF_REQUEST);
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==CREATE_PDF_REQUEST){
            if(resultCode==RESULT_OK&&data!=null&&data.getData()!=null&&pendingPdf!=null){
                final Uri dest=data.getData();final byte[] output=pendingPdf;
                io.execute(()->{
                    try(java.io.OutputStream out=getContentResolver().openOutputStream(dest)){
                        if(out==null)throw new java.io.IOException("无法打开目标文件");
                        out.write(output);out.flush();ui.post(()->toast("A4 PDF 已保存"));
                    }catch(Exception e){ui.post(()->toast("保存失败："+e.getMessage()));}
                });
            }
            pendingPdf=null;
        }
    }
    private void printPdf(){
        byte[] pdf=createPdfOrNotify();if(pdf==null)return;
        int pageCount=(sheetCount()+3)/4;
        PrintManager manager=(PrintManager)getSystemService(PRINT_SERVICE);
        if(manager==null){toast("设备没有打印服务");return;}
        PrintAttributes attrs=new PrintAttributes.Builder()
                .setMediaSize(PrintAttributes.MediaSize.ISO_A4.asLandscape())
                .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                .setColorMode(PrintAttributes.COLOR_MODE_MONOCHROME).build();
        manager.print("OFERTA A4",new PdfAdapter(pdf,pageCount),attrs);
    }
    private final class PdfAdapter extends PrintDocumentAdapter {
        private final byte[] bytes;private final int pageCount;
        PdfAdapter(byte[] data,int count){bytes=data;pageCount=count;}
        @Override public void onLayout(PrintAttributes oldAttrs,PrintAttributes attrs,CancellationSignal signal,
                LayoutResultCallback cb,Bundle extras){
            if(signal.isCanceled()){cb.onLayoutCancelled();return;}
            cb.onLayoutFinished(new PrintDocumentInfo.Builder("OFERTA_A4.pdf")
                    .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT).setPageCount(pageCount).build(),true);
        }
        @Override public void onWrite(android.print.PageRange[] pages,ParcelFileDescriptor target,
                CancellationSignal signal,WriteResultCallback callback){
            // Android print spooler may request subsets; provide the complete document.
            io.execute(()->{
                try(FileOutputStream stream=new FileOutputStream(target.getFileDescriptor())){
                    if(signal.isCanceled()){ui.post(callback::onWriteCancelled);return;}
                    stream.write(bytes);stream.flush();
                    ui.post(()->callback.onWriteFinished(new android.print.PageRange[]{android.print.PageRange.ALL_PAGES}));
                }catch(Exception e){ui.post(()->callback.onWriteFailed(e.getMessage()));}
            });
        }
    }

    private void scanBarcode(){
        GmsBarcodeScannerOptions opts=new GmsBarcodeScannerOptions.Builder()
                .setBarcodeFormats(Barcode.FORMAT_EAN_13,Barcode.FORMAT_EAN_8,
                        Barcode.FORMAT_UPC_A,Barcode.FORMAT_UPC_E,Barcode.FORMAT_CODE_128)
                .enableAutoZoom().build();
        GmsBarcodeScanner scanner=GmsBarcodeScanning.getClient(this,opts);
        scanner.startScan().addOnSuccessListener(barcode->{
            String raw=barcode.getRawValue();
            if(raw!=null&&!raw.isEmpty()){barcodeInput.setText(raw);fetchProduct();}
        }).addOnFailureListener(e->toast("扫码失败，请确认 Google Play 服务正常，或手动输入条码："+e.getMessage()));
    }
    private void fetchProduct(){
        final String code=trim(barcodeInput);
        if(!code.matches("\\d{8,14}")){barcodeInput.setError("请输入 8—14 位数字条形码");return;}
        String cached=prefs.getString("product_"+code,null);
        if(cached!=null){try{applyProduct(new JSONObject(cached));status.setText("已使用本地商品信息，可手动修改。 ");return;}
            catch(Exception ignored){} }
        long now=SystemClock.elapsedRealtime();
        if(now-lastNetworkAt<4100){status.setText("请稍后再查，防止超过免费接口调用限制。 ");return;}
        lastNetworkAt=now;
        status.setText("正在查询 Open Food Facts...");
        io.execute(()->{
            HttpURLConnection c=null;
            try {
                // OFF API v3: no key; use a dedicated User-Agent. Add real contact in production.
                URL u=new URL("https://world.openfoodfacts.org/api/v3/product/"+code+
                        "?fields=product_name,product_name_es,brands,quantity&lc=es&cc=ar");
                c=(HttpURLConnection)u.openConnection();c.setRequestMethod("GET");
                c.setRequestProperty("User-Agent","OfertaA4/1.0 (Android personal supermarket label app)");
                c.setRequestProperty("Accept","application/json");
                c.setConnectTimeout(10000);c.setReadTimeout(12000);
                int http=c.getResponseCode();
                if(http==404){ui.post(()->status.setText("商品库中没有该条码，可以手动填写名称、品牌。"));return;}
                if(http==429||http==503){ui.post(()->status.setText("Open Food Facts 查询受限，请稍后重试或手动输入。"));return;}
                if(http!=200)throw new Exception("HTTP "+http);
                StringBuilder json=new StringBuilder();
                try(InputStream in=c.getInputStream();BufferedReader reader=new BufferedReader(new InputStreamReader(in,java.nio.charset.StandardCharsets.UTF_8))){
                    String line;while((line=reader.readLine())!=null)json.append(line);
                }
                JSONObject root=new JSONObject(json.toString());
                JSONObject product=root.optJSONObject("product");
                if(product==null||product.length()==0){ui.post(()->status.setText("商品没有找到，可直接手动填写。"));return;}
                prefs.edit().putString("product_"+code,product.toString()).apply();
                ui.post(()->{if(code.equals(trim(barcodeInput))){applyProduct(product);status.setText("查询成功。请确认商品规格并输入原价、优惠价。 ");}});
            } catch(Exception ex){ui.post(()->status.setText("网络查询失败（"+ex.getMessage()+"），可以手动填写。"));}
            finally {if(c!=null)c.disconnect();}
        });
    }
    private void applyProduct(JSONObject data){
        String name=data.optString("product_name_es","").trim();
        if(name.isEmpty())name=data.optString("product_name","").trim();
        String brand=data.optString("brands","").trim();
        String quantity=data.optString("quantity","").trim();
        if(!quantity.isEmpty() && !name.toLowerCase(Locale.ROOT).contains(quantity.toLowerCase(Locale.ROOT)))
            name=(name+" "+quantity).trim();
        if(!name.isEmpty())nameInput.setText(name);
        if(!brand.isEmpty())brandInput.setText(brand);
        if(name.isEmpty() && brand.isEmpty())status.setText("数据库只有部分资料，请手动填写名称和品牌。 ");
    }

    private void persistQueue(){
        JSONArray arr=new JSONArray();
        try{for(OfferItem item:queue){JSONObject j=new JSONObject();
            j.put("code",item.barcode);j.put("name",item.name);j.put("brand",item.brand);
            j.put("old",item.before);j.put("now",item.now);j.put("copies",item.copies);
            j.put("style",item.style);arr.put(j);
        }}catch(Exception ignored){}
        prefs.edit().putString("queue",arr.toString()).apply();
    }
    private void loadQueue(){
        try {JSONArray arr=new JSONArray(prefs.getString("queue","[]"));
            for(int i=0;i<arr.length();i++){JSONObject j=arr.getJSONObject(i);
                queue.add(new OfferItem(j.optString("code"),j.optString("name"),j.optString("brand"),
                        j.optString("old"),j.optString("now"),Math.max(1,Math.min(99,j.optInt("copies",1))),
                        Math.max(1,Math.min(8,j.optInt("style",1)))));
            }
        }catch(Exception e){queue.clear();}
    }

    private static BigDecimal parsePrice(String original){
        if(original==null)return null;
        String v=original.replace("$","").replaceAll("(?i)ars","").replace(" ","").trim();
        if(!v.matches("[0-9][0-9.,]*"))return null;
        int comma=v.lastIndexOf(','),dot=v.lastIndexOf('.');
        if(comma>=0){v=v.replace(".","").replace(',','.');}
        else if(dot>=0){
            // Argentine prices like 3.500: a dot followed by exactly 3 digits is a grouping separator.
            if(v.length()-dot-1==3)v=v.replace(".","");
            else if(v.indexOf('.')!=dot)v=v.replace(".","");
        }
        try{return new BigDecimal(v).setScale(2,RoundingMode.HALF_UP);}catch(Exception e){return null;}
    }
    private static String normalizePrice(String original){
        BigDecimal v=parsePrice(original);if(v==null||v.signum()<=0)return null;
        DecimalFormatSymbols syms=new DecimalFormatSymbols(new Locale("es","AR"));
        syms.setGroupingSeparator('.');syms.setDecimalSeparator(',');
        DecimalFormat format=new DecimalFormat("#,##0.##",syms);
        boolean decimals=original.contains(",") ||
                (original.matches(".*\\.\\d{1,2}$") && !original.contains(","));
        format.setMinimumFractionDigits(decimals?2:0);format.setMaximumFractionDigits(2);
        return format.format(v);
    }

    private int dp(float d){return (int)(d*getResources().getDisplayMetrics().density+0.5f);}
    private static String trim(EditText edit){return edit.getText().toString().trim();}
    private LinearLayout row(){LinearLayout r=new LinearLayout(this);r.setGravity(Gravity.CENTER_VERTICAL);
        r.setOrientation(LinearLayout.HORIZONTAL);return r;}
    private LinearLayout.LayoutParams weight(){return new LinearLayout.LayoutParams(0,-2,1f);}
    private TextView text(String value,int size,boolean bold){TextView tv=new TextView(this);tv.setText(value);
        tv.setTextColor(INK);tv.setTextSize(size);tv.setPadding(dp(3),dp(4),dp(3),dp(4));
        if(bold)tv.setTypeface(android.graphics.Typeface.DEFAULT,android.graphics.Typeface.BOLD);
        return tv;}
    private TextView section(String value){TextView tv=text(value,18,true);tv.setPadding(dp(0),dp(8),0,dp(8));return tv;}
    private EditText field(String hint,int inputType){EditText et=new EditText(this);et.setHint(hint);
        et.setSingleLine(true);et.setTextSize(17);et.setTextColor(INK);et.setInputType(inputType);
        et.setPadding(dp(7),dp(8),dp(7),dp(8));
        et.setLayoutParams(new LinearLayout.LayoutParams(-1,-2));return et;}
    private Button button(String caption,boolean filled){Button b=new Button(this);b.setText(caption);
        b.setTextSize(13);b.setAllCaps(false);
        b.setTextColor(filled?Color.WHITE:Color.BLACK);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(filled?0xff111111:0xffeeeeee));
        b.setMinimumHeight(dp(44));return b;}
    private void space(LinearLayout root,int px){View v=new View(this);root.addView(v,new LinearLayout.LayoutParams(1,dp(px)));}
    private void toast(String value){Toast.makeText(this,value,Toast.LENGTH_LONG).show();}
    private final class PreviewView extends View {
        private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
        PreviewView(){super(MainActivity.this);setBackgroundColor(0xfff4f4f4);}
        @Override protected void onDraw(Canvas canvas){super.onDraw(canvas);
            float sx=(getWidth()-dp(12))/OfferRenderer.CELL_W;
            float sy=(getHeight()-dp(12))/OfferRenderer.CELL_H;
            float s=Math.min(sx,sy);
            float dx=(getWidth()-OfferRenderer.CELL_W*s)/2f;
            float dy=(getHeight()-OfferRenderer.CELL_H*s)/2f;
            canvas.save();canvas.translate(dx,dy);canvas.scale(s,s);
            OfferRenderer.drawOffer(canvas,sampleOffer(),fonts);
            paint.setColor(Color.BLACK);paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(0.8f);
            canvas.drawRect(0,0,OfferRenderer.CELL_W,OfferRenderer.CELL_H,paint);
            paint.setStyle(Paint.Style.FILL);canvas.restore();
        }
    }
    private final class PagePreviewView extends View {
        private final Paint border=new Paint(Paint.ANTI_ALIAS_FLAG);
        PagePreviewView(){super(MainActivity.this);setBackgroundColor(0xfff4f4f4);}
        @Override protected void onDraw(Canvas canvas){super.onDraw(canvas);
            float sx=(getWidth()-dp(12))/(float)OfferRenderer.PAGE_W;
            float sy=(getHeight()-dp(12))/(float)OfferRenderer.PAGE_H;
            float s=Math.min(sx,sy);
            float dx=(getWidth()-OfferRenderer.PAGE_W*s)/2f;
            float dy=(getHeight()-OfferRenderer.PAGE_H*s)/2f;
            canvas.save();canvas.translate(dx,dy);canvas.scale(s,s);
            OfferRenderer.drawPage(canvas,OfferRenderer.expand(queue),0,fonts);
            border.setColor(Color.BLACK);border.setStyle(Paint.Style.STROKE);border.setStrokeWidth(.8f);
            canvas.drawRect(0,0,OfferRenderer.PAGE_W,OfferRenderer.PAGE_H,border);
            border.setStyle(Paint.Style.FILL);canvas.restore();
        }
    }
    @Override protected void onDestroy(){io.shutdown();super.onDestroy();}
}
