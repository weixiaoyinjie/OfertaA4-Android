package com.tienda.ofertaa4;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.pdf.PdfDocument;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** One renderer for real A4 PDFs, printer output, and live screen previews. */
public final class OfferRenderer {
    // Android PdfDocument uses integer PDF points. A4 landscape is ~842 x 595 points.
    public static final int PAGE_W = 842;
    public static final int PAGE_H = 595;
    public static final float CELL_W = PAGE_W / 2f;
    public static final float CELL_H = PAGE_H / 2f;
    private static final Typeface HEAVY = Typeface.create("sans-serif-condensed-black", Typeface.BOLD);
    private static final Typeface BOLD = Typeface.create("sans-serif-condensed", Typeface.BOLD);
    private static final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.SUBPIXEL_TEXT_FLAG);

    // Individual, persisted font percentages, not image scaling. They affect the final PDF.
    public static final class Fonts {
        public int headline = 100;
        public int product = 100;
        public int original = 100;
        public int special = 100;
        public Fonts copy() {
            Fonts result = new Fonts(); result.headline = headline; result.product = product;
            result.original = original; result.special = special; return result;
        }
    }

    public static List<OfferItem> expand(List<OfferItem> items) {
        List<OfferItem> all = new ArrayList<>();
        for (OfferItem item : items) for(int k=0; k<Math.max(0,Math.min(99,item.copies)); k++) all.add(item);
        return all;
    }

    public static int pages(List<OfferItem> expanded) { return (expanded.size() + 3) / 4; }

    public static byte[] pdf(List<OfferItem> items, Fonts fonts) throws IOException {
        List<OfferItem> all = expand(items);
        if (all.isEmpty()) throw new IOException("请先加入商品");
        PdfDocument pdf = new PdfDocument();
        try {
            for (int pageIndex=0; pageIndex<pages(all); pageIndex++) {
                PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(PAGE_W, PAGE_H, pageIndex+1).create();
                PdfDocument.Page page = pdf.startPage(pageInfo);
                drawPage(page.getCanvas(), all, pageIndex, fonts);
                pdf.finishPage(page);
            }
            ByteArrayOutputStream stream = new ByteArrayOutputStream();
            pdf.writeTo(stream);
            return stream.toByteArray();
        } finally { pdf.close(); }
    }

    public static void drawPage(Canvas c, List<OfferItem> expanded, int pageIndex, Fonts fonts) {
        c.drawColor(Color.WHITE);
        for(int i=0;i<4;i++) {
            int index = pageIndex*4+i;
            if(index >= expanded.size()) continue;  // Partial last page stays blank.
            c.save(); c.translate((i%2)*CELL_W, (i/2)*CELL_H);
            drawOffer(c, expanded.get(index), fonts);
            c.restore();
        }
        p.reset(); p.setColor(Color.BLACK); p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(0.65f); p.setPathEffect(new DashPathEffect(new float[]{5,5},0));
        c.drawLine(CELL_W,0,CELL_W,PAGE_H,p);
        c.drawLine(0,CELL_H,PAGE_W,CELL_H,p);
        p.setPathEffect(null); p.setStyle(Paint.Style.FILL);
    }

    /** Local canvas coordinates: x:[0..421], y:[0..297.5]. */
    public static void drawOffer(Canvas canvas, OfferItem item, Fonts fonts) {
        canvas.save();
        canvas.clipRect(0,0,CELL_W,CELL_H);
        canvas.drawColor(Color.WHITE);
        float L = 12, R = CELL_W-12;
        float mid = CELL_W/2f;
        int style = Math.max(1,Math.min(8,item.style));
        boolean blackBand = (style==1 || style==3 || style==5 || style==7 || style==8);
        boolean framed = (style==4 || style==8);
        if(framed) {
            p.reset(); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2.2f); p.setColor(Color.BLACK);
            canvas.drawRect(7,7,CELL_W-7,CELL_H-7,p); p.setStyle(Paint.Style.FILL);
        }
        String headline = heading(style);
        if(blackBand) {
            p.reset(); p.setColor(Color.BLACK);
            if(style==8) canvas.drawRoundRect(new RectF(L,9,R,76),8,8,p);
            else canvas.drawRect(L,9,R,76,p);
            text(canvas,headline,mid,61,Math.min(63f,46f*fonts.headline/100f),R-L-12,HEAVY,Color.WHITE);
        } else {
            text(canvas,headline,mid,60,Math.min(63f,46f*fonts.headline/100f),R-L-5,HEAVY,Color.BLACK);
            line(canvas,L,75,R,75,style==4?4f:2.2f);
        }
        float priceSize = Math.min(146f, 92f*fonts.special/100f);
        boolean priceDominates = priceSize > 113f;
        String name = item.name == null?"":item.name.trim().toUpperCase(Locale.ROOT);
        if(name.isEmpty()) name="NOMBRE DEL PRODUCTO";
        String brand = item.brand == null?"":item.brand.trim().toUpperCase(Locale.ROOT);
        // Split long names; glyphs are never clipped horizontally.
        float productFont = 34f*fonts.product/100f;
        boolean split = fittedSize(name,productFont,R-L-10,HEAVY)<23f && name.length()>10;
        boolean showBrand = !brand.isEmpty() && !priceDominates && fonts.original<125;
        if(split) {
            String[] pieces = splitName(name);
            text(canvas,pieces[0],mid,priceDominates?96:106,productFont,R-L-10,HEAVY,Color.BLACK);
            text(canvas,pieces[1],mid,priceDominates?119:137,productFont,R-L-10,HEAVY,Color.BLACK);
            if(showBrand) text(canvas,brand,mid,152,14,R-L-14,BOLD,Color.BLACK);
        } else {
            text(canvas,name,mid,priceDominates?109:123,productFont,R-L-10,HEAVY,Color.BLACK);
            if(showBrand) text(canvas,brand,mid,146,16,R-L-14,BOLD,Color.BLACK);
        }
        // Original price with diagonal strike-through only on price, not the label.
        String before = money(item.before);
        float oldFont = Math.min(priceDominates?23f:36f,22f*fonts.original/100f);
        float oldY = priceDominates ? 146f : 177f;
        String prefix="ANTES ";
        p.reset(); p.setTypeface(BOLD); p.setFakeBoldText(true);
        p.setTextSize(oldFont);
        float oldWidth = p.measureText(prefix+before);
        if(oldWidth>R-L-10) {
            oldFont*= (R-L-10)/oldWidth;
            p.setTextSize(oldFont); oldWidth=p.measureText(prefix+before);
        }
        float start=mid-oldWidth/2f;
        p.setTextAlign(Paint.Align.LEFT);p.setColor(Color.BLACK);
        canvas.drawText(prefix+before,start,oldY,p);
        float preWidth=p.measureText(prefix);
        line(canvas,start+preWidth-1,oldY-4,start+oldWidth+2,oldY-9,2.1f);
        text(canvas,style==6?"PRECIO REBAJADO":"AHORA",mid,priceDominates?168:202,
                style==6?19:20,R-L-12,HEAVY,Color.BLACK);
        // Height adapts when users enlarge the promo price: earlier fields move up.
        String special = money(item.now);
        text(canvas,special,mid,287,priceSize,R-L-8,HEAVY,Color.BLACK);
        canvas.restore();
    }

    public static String heading(int s) {
        switch(s) {
            case 2: return "¡SUPER OFERTA!";
            case 3: return "PRECIO ESPECIAL";
            case 5: return "GRAN OFERTA";
            case 6: return "REBAJA";
            case 7: return "¡OFERTÓN!";
            case 8: return "OFERTA DEL DÍA";
            default: return "OFERTA";
        }
    }

    public static String money(String raw) {
        String s = raw==null?"":raw.trim();
        if(s.isEmpty()) return "$ 0";
        if(s.startsWith("$") || s.startsWith("ARS")) return s;
        return "$ " + s;
    }

    private static void text(Canvas c,String text,float x,float baseline,float size,float maxWidth,Typeface face,int color) {
        p.reset();p.setAntiAlias(true);p.setSubpixelText(true);p.setTypeface(face);
        p.setFakeBoldText(true); p.setColor(color);p.setStyle(Paint.Style.FILL);
        p.setTextAlign(Paint.Align.CENTER);p.setTextSize(Math.max(7,fittedSize(text,size,maxWidth,face)));
        c.drawText(text,x,baseline,p);
        p.setFakeBoldText(false);
    }
    private static float fittedSize(String s,float size,float maxWidth,Typeface face) {
        p.setTypeface(face); p.setTextSize(size);p.setFakeBoldText(true);
        float w=p.measureText(s);
        return (w>maxWidth && w>0)?size*maxWidth/w:size;
    }
    private static void line(Canvas c,float x,float y,float x1,float y1,float sw) {
        p.reset();p.setColor(Color.BLACK);p.setStrokeWidth(sw);p.setStyle(Paint.Style.STROKE);
        c.drawLine(x,y,x1,y1,p);p.setStyle(Paint.Style.FILL);
    }
    private static String[] splitName(String text) {
        String[] ws=text.split("\\s+");
        if(ws.length==1) {
            int half=text.length()/2;
            return new String[]{text.substring(0,half),text.substring(half)};
        }
        int best=1,smallest=Integer.MAX_VALUE;
        for(int k=1;k<ws.length;k++) {
            String a=join(ws,0,k),b=join(ws,k,ws.length);
            int delta=Math.abs(a.length()-b.length());
            if(delta<smallest){best=k;smallest=delta;}
        }
        return new String[]{join(ws,0,best),join(ws,best,ws.length)};
    }
    private static String join(String[] ws,int i,int end) {
        StringBuilder b=new StringBuilder();
        for(int k=i;k<end;k++) {if(b.length()!=0)b.append(' ');b.append(ws[k]);}
        return b.toString();
    }
    private OfferRenderer(){}
}
