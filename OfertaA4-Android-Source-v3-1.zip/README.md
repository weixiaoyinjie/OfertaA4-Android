# OFERTA A4/A3 1.3 — 阿根廷超市特价纸 Android App

## 功能

- **A4 横向 2×2**：A4 297 × 210 毫米，裁成 4 张横版标签，每张 148.5 × 105 毫米。
- **A3 横向 3×3**：A3 420 × 297 毫米，裁成 9 张横版标签，每张 140 × 99 毫米。
- 每个商品设置打印份数（1—99），按添加顺序凑成一页；最后一页不足九格或四格保持空白。份数不是购买件数。
- 分开输入：**品牌 MARCA**、**商品名称 NOMBRE**、**口味或品种 VARIEDAD/SABOR**、**容量 CONTENIDO**、单件原价 ANTES、优惠价 AHORA。
- Open Food Facts + ML Kit 条码扫描；当来源明确写出 Malbec、Cabernet Sauvignon、Frutilla、Vainilla 等才尝试识别；其他情况留空手动编辑。
- 8 种**纯黑白、白底黑字促销标题**模板（OFERTA 等促销大字取消旧版黑底横框，留白更醒目） + 6 种**彩色**模板（共 14 种）；黑白模式会覆盖任何彩色模板为黑白输出。
- 单件促销与两件合计促销（LLEVANDO 2 UNIDADES · TOTAL）；不能误把两件的合计价当单价。
- 品牌、商品名称、原价、标题和特价数字分别调整字号，手机预览与实际 PDF 共用绘图器。
- 可导出真正的矢量 PDF，或者使用 Android 打印系统打印。中间裁剪虚线。
- 兼容读取旧版本 1.1 保存的打印清单；旧商品没有口味、规格字段时默认为空。

## 数据准确性

Open Food Facts 是用户贡献数据库，不保证阿根廷每种商品都收录，不保证每条商品都提供口味/品种。即使扫到相同品牌，也不可假定红酒葡萄品种或酸奶口味。请检查输入的 `VARIEDAD/SABOR` 字段。条码查询不读取照片中的包装文字；未来可单独加入 OCR 识别。

## 升级现有 GitHub 仓库

仓库： https://github.com/weixiaoyinjie/OfertaA4-Android

1. 上传 `OfertaA4-Android-Source-v3.zip`（**以完整 ZIP 文件上传，不要在 GitHub 网页中解压**）。
2. 打开 `.github/workflows/build.yml`，用附带的 `build.yml` 内容替换整个文件。该工作流会先解压 V3 源码再执行 Gradle。
3. 在 **Actions** 页查看 `Build OFERTA A4 A3 APK`，编译成功后下载 `OfertaA4-A3-v3-debug-apk`，解压得到 `app-debug.apk`。

如希望建立全新 Android 仓库，可以解压源码后上传全部文件（包括隐藏的 `.github` 目录），然后同样通过 Actions 编译。

## Android 环境

- Java 17；Gradle 8.11.1；Android Gradle Plugin 8.9.2，compileSdk 35。
- minSdk 23；Google ML Kit Code Scanner 使用 Google Play 服务。扫码无需摄像头权限；Open Food Facts 需要联网。
- PDF 采用 `PdfDocument` 标准点数（A4 横向约 842×595 pt；A3 横向约 1191×842 pt）。
- 打印时请确认纸张是 A3 或 A4、**横向**、**100% 实际尺寸**；非无边距打印机可能缩小/裁掉边缘，实物尺寸取决于打印机能力。

## 编译声明

该软件包完成静态源码检查与 ZIP 结构验证，尚未在此环境中完成 Android SDK + Gradle 的 APK 实际编译。首次构建如遇错误，请提供 Actions 中失败步骤的最后几行。

## V3.1 修改说明：黑白促销标题不再使用黑色横幅

- 所有黑白模板（包括强制黑白输出的彩色样式），OFERTA、SUPER OFERTA、PRECIO ESPECIAL 等**全部改为白纸底 + 超粗黑字**。
- 删除旧版标题外围的大块黑色实心矩形；促销字上方、下方保留白色纸面，不会出现黑底白字。
- 适用于 A4 横向四格和 A3 横向九格、手机单张预览、整页预览和打印 PDF（共用 OfferRenderer）。
- 彩色打印模式保持彩色标题横幅不变；品牌、名称、品种、规格、促销价及每件打印份数不变。
- 版本号更新为 1.3，Android `versionCode` 更新为 4。

GitHub 编译需使用新的 `OfertaA4-Android-Source-v3-1.zip` 和同包附带的 `build.yml`。
