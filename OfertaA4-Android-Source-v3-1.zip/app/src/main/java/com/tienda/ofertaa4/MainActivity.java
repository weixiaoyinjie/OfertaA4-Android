package com.tienda.ofertaa4;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintDocumentInfo;
import android.print.PrintManager;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.common.api.ApiException;
import com.google.mlkit.vision.barcode.common.Barcode;
import com.google.mlkit.vision.codescanner.GmsBarcodeScanner;
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions;
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.ArrayList;
import java.util.List;
import java.util.HashMap;
import java.util.Map;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int CREATE_PDF_REQUEST=102;
    private static final int INK=Color.BLACK;
    private static final int BORDER=0xffd0d0d0;
    private final List<OfferItem> queue = new ArrayList<>();
    private final Map<String,SeekBar> fontSeekBars=new HashMap<>();
    private final ExecutorService io=Executors.newSingleThreadExecutor();
    private final Handler ui=new Handler(Looper.getMainLooper());
    private OfferRenderer.Fonts fonts=new OfferRenderer.Fonts();
    private SharedPreferences prefs;
    private EditText barcodeInput,nameInput,brandInput,varietyInput,quantityInput,oldInput,nowInput,copiesInput;
    private Spinner styleSpinner, offerModeSpinner, paperSpinner, paletteSpinner;
    private int styleBW=0,styleColor=0;
    private boolean updatingStyle=false;
    private LinearLayout queueLayout;
    private TextView status,queueStats,pagePreviewCaption,paperInstructions;
    private PreviewView preview;
    private PagePreviewView pagePreview;
    private ScrollView scroller;
    private byte[] pendingPdf;
    private long lastNetworkAt=0;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs=getSharedPreferences("oferta-a4-v1",MODE_PRIVATE);
        fonts.headline=prefs.getInt("font_headline",100);
        fonts.product=prefs.getInt("font_product",100);
        fonts.brand=prefs.getInt("font_brand",100);
        fonts.original=prefs.getInt("font_original",100);
        fonts.special=prefs.getInt("font_special",100);
        loadQueue();
        styleBW=Math.max(0,Math.min(7,prefs.getInt("last_bw_style",0)));
        styleColor=Math.max(0,Math.min(5,prefs.getInt("last_color_style",0)));
        createUi();
        updateQueue();
    }

    private void createUi() {
        fontSeekBars.clear();
        ScrollView sc=new ScrollView(this);scroller=sc;sc.setFillViewport(true);
        LinearLayout root=new LinearLayout(this);root.setPadding(dp(15),dp(18),dp(15),dp(30));
        root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.WHITE);
        sc.addView(root);setContentView(sc);
        TextView title=text("OFERTA A4 / A3",29,true);root.addView(title);
        root.addView(text("A4 横向四格或 A3 横向九格｜彩色／黑白模板｜按份数混排",13,false));
        root.addView(section("打印纸张与颜色"));
        root.addView(text("打印纸张",14,true));
        paperSpinner=new Spinner(this);
        paperSpinner.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,
                new String[]{"A4 横向 · 4 张 (2×2)，每张 14.85×10.5 厘米",
                        "A3 横向 · 9 张 (3×3)，每张 14×9.9 厘米"}));
        paperSpinner.setSelection(Math.max(0,Math.min(1,prefs.getInt("paper_size",0))));
        root.addView(paperSpinner);
        root.addView(text("打印颜色 / 模板类别",14,true));
        paletteSpinner=new Spinner(this);
        paletteSpinner.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,
                new String[]{"黑白打印 · 省墨款式", "彩色打印 · 彩色促销款式"}));
        paletteSpinner.setSelection(Math.max(0,Math.min(1,prefs.getInt("palette",0))));
        root.addView(paletteSpinner);
        root.addView(text("PDF 按所选颜色输出；选黑白时任何彩色模板都会转换成黑白。",12,false));
        space(root,14);
        root.addView(section("① 扫描条形码 / 查询商品"));
        barcodeInput=field("条形码：EAN-8 / EAN-13 / UPC",InputType.TYPE_CLASS_NUMBER);
        root.addView(barcodeInput);
        LinearLayout scanRow=row();
        Button scan=button("扫码",true), lookup=button("查询名称和品牌",false);
        scanRow.addView(scan,weight());scanRow.addView(lookup,weight());root.addView(scanRow);
        scan.setOnClickListener(v->scanBarcode());lookup.setOnClickListener(v->fetchProduct());
        status=text("扫码后从 Open Food Facts 查询；查不到也可以手动填写。",12,false);
        status.setTextColor(0xff555555);root.addView(status);
        space(root,14);
        root.addView(section("② 商品与价格"));
        nameInput=field("商品名称（可修改）",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        brandInput=field("品牌 MARCA，例如 Cordero con Piel de Lobo",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        varietyInput=field("品种 / 口味 VARIEDAD / SABOR，例如 MALBEC、FRUTILLA",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        quantityInput=field("容量 / 克数 CONTENIDO，例如 750 ml、950 g",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        oldInput=field("原价 ANTES，例如 3.500",InputType.TYPE_CLASS_TEXT);
        nowInput=field("优惠价 AHORA，例如 2.790",InputType.TYPE_CLASS_TEXT);
        root.addView(nameInput);root.addView(brandInput);root.addView(varietyInput);root.addView(quantityInput);
        root.addView(text("请核对口味和品种：同一个品牌不同 MALBEC、CABERNET SAUVIGNON、草莓味等会分别打印。",12,false));
        root.addView(text("促销方式",14,true));
        offerModeSpinner=new Spinner(this);
        String[] modes={"单件特价 · AHORA", "买 2 件合计特价 · LLEVANDO 2"};
        offerModeSpinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, modes));
        offerModeSpinner.setSelection(Math.max(0,Math.min(1,prefs.getInt("last_offer_mode",0))));
        root.addView(offerModeSpinner);
        TextView modeExplanation=text("原价和优惠价都表示单件价格。",12,false);
        root.addView(modeExplanation);
        root.addView(oldInput);root.addView(nowInput);
        offerModeSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(android.widget.AdapterView<?> parent,View view,int position,long id) {
                boolean two=position==1;
                oldInput.setHint(two ? "每件原价 ANTES C/U，例如 3.500" : "原价 ANTES，例如 3.500");
                nowInput.setHint(two ? "两件合计优惠价，例如 6.000" : "单件优惠价 AHORA，例如 2.790");
                modeExplanation.setText(two ? "两件总价：例如原价 $ 3.500/件，2 件合计特价 $ 6.000。打印将写明价格为两件总价。" : "单件特价：原价和优惠价都表示每件的价格。");
                prefs.edit().putInt("last_offer_mode",position).apply();
                if(preview!=null)preview.invalidate();
            }
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent) {}
        });
        root.addView(text("促销样式（不同颜色组有不同的模板）",14,true));
        styleSpinner=new Spinner(this);
        root.addView(styleSpinner);
        updateStyleList();
        paletteSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(android.widget.AdapterView<?> parent,View view,int pos,long id) {
                prefs.edit().putInt("palette",pos).apply();
                updateStyleList();
                if(preview!=null)preview.invalidate();
                if(pagePreview!=null)pagePreview.invalidate();
            }
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent) {}
        });
        paperSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(android.widget.AdapterView<?> parent,View view,int pos,long id) {
                prefs.edit().putInt("paper_size",pos).apply();
                updateQueue();
                if(pagePreviewCaption!=null)pagePreviewCaption.setText(sheet().name+" 第一页拼版预览（"+sheet().cols+"×"+sheet().rows+"）");
                if(paperInstructions!=null)paperInstructions.setText(sheetInstructions());
            }
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent) {}
        });
        root.addView(text("这款商品需要打印几张？",14,true));
        copiesInput=field("份数（1—99）",InputType.TYPE_CLASS_NUMBER);copiesInput.setText("1");root.addView(copiesInput);
        Button add=button("＋ 添加到打印清单",true);root.addView(add);add.setOnClickListener(v->addOffer());
        space(root,14);
        root.addView(section("③ 手动放大 / 缩小打印字体"));
        root.addView(text("分别调节促销标题、品牌、商品名、原价和特价数字。文字过长时会自动缩小防止截断。",12,false));
        root.addView(slider("OFERTA / 促销标题", "font_headline",60,160,fonts.headline,x->fonts.headline=x));
        root.addView(slider("品牌 / MARCA", "font_brand",60,170,fonts.brand,x->fonts.brand=x));
        root.addView(slider("商品名称", "font_product",60,160,fonts.product,x->fonts.product=x));
        root.addView(slider("原价 ANTES", "font_original",60,160,fonts.original,x->fonts.original=x));
        root.addView(slider("特价数字 AHORA", "font_special",60,170,fonts.special,x->fonts.special=x));
        Button reset=button("恢复默认字体 100%",false);root.addView(reset);
        reset.setOnClickListener(v->{
            for(SeekBar bar:fontSeekBars.values())bar.setProgress(100-60);
            toast("字号已恢复至 100%");
        });
        space(root,10);
        root.addView(section("④ 实时打印预览（单张）"));
        preview=new PreviewView();root.addView(preview,new LinearLayout.LayoutParams(-1,dp(225)));
        root.addView(text("同一矢量绘图用于手机预览和 PDF；A4、A3 促销纸均为宽长方形。",12,false));
        space(root,15);
        root.addView(section("⑤ 打印清单：自动混排"));
        queueStats=text("",14,true);root.addView(queueStats);
        pagePreviewCaption=text(sheet().name+" 第一页拼版预览（"+sheet().cols+"×"+sheet().rows+"）",12,false);
        root.addView(pagePreviewCaption);
        pagePreview=new PagePreviewView();root.addView(pagePreview,new LinearLayout.LayoutParams(-1,dp(245)));
        queueLayout=new LinearLayout(this);queueLayout.setOrientation(LinearLayout.VERTICAL);root.addView(queueLayout);
        LinearLayout actionRow=row();
        Button save=button("导出 PDF",true),print=button("直接打印",true);
        actionRow.addView(save,weight());actionRow.addView(print,weight());root.addView(actionRow);
        save.setOnClickListener(v->savePdf());print.setOnClickListener(v->printPdf());
        Button clear=button("清空打印清单",false);root.addView(clear);
        clear.setOnClickListener(v->new AlertDialog.Builder(this).setMessage("确定清空全部特价纸吗？")
                .setNegativeButton("取消",(d,w)->{}).setPositiveButton("清空",(d,w)->{queue.clear();persistQueue();updateQueue();}).show());
        root.addView(text("扫码来源：Open Food Facts；商品名称、品牌、规格及口味可能缺失或不准确，请确认后打印。",11,false));
        root.addView(text("买2件模式中：原价=每件原价；促销价=两件合计总价。打印份数指纸张张数，不是商品件数。",12,false));
        paperInstructions=text(sheetInstructions(),12,false);root.addView(paperInstructions);
        attachPreviewListener(nameInput);attachPreviewListener(brandInput);attachPreviewListener(varietyInput);
        attachPreviewListener(quantityInput);attachPreviewListener(oldInput);attachPreviewListener(nowInput);
        styleSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(android.widget.AdapterView<?> parent,View view,int pos,long id) {
                if(!updatingStyle){
                    if(isColor()) {styleColor=pos;prefs.edit().putInt("last_color_style",pos).apply();}
                    else {styleBW=pos;prefs.edit().putInt("last_bw_style",pos).apply();}
                }
                if(preview!=null)preview.invalidate();
            }
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent) {}
        });
    }

    private boolean isColor(){return paletteSpinner!=null && paletteSpinner.getSelectedItemPosition()==1;}
    private OfferRenderer.Sheet sheet(){return paperSpinner!=null && paperSpinner.getSelectedItemPosition()==1?
            OfferRenderer.Sheet.A3:OfferRenderer.Sheet.A4;}
    private int selectedStyle(){return isColor()?9+Math.max(0,styleSpinner.getSelectedItemPosition()):
            1+Math.max(0,styleSpinner.getSelectedItemPosition());}
    private String sheetInstructions(){
        OfferRenderer.Sheet f=sheet();
        return "示例：同一商品×2，其他商品各×1，可以混合打印；"+f.name+" 每页 "+f.perPage()+" 张。\n"+
                "打印时请选择 "+f.name+"、横向、100% 实际大小，沿虚线剪裁。非无边距打印机可能出现打印留白。";
    }
    private void updateStyleList() {
        if(styleSpinner==null||paletteSpinner==null)return;
        updatingStyle=true;
        String[] bw={"01 · OFERTA 白底黑色大字", "02 · ¡SUPER OFERTA! 白底黑字",
                "03 · PRECIO ESPECIAL 白底黑字", "04 · OFERTA 黑色粗体",
                "05 · GRAN OFERTA", "06 · REBAJA 粗体", "07 · ¡OFERTÓN!", "08 · OFERTA DEL DÍA"};
        String[] color={"09 · 经典红色 OFERTA", "10 · 黄色 SUPER OFERTA", "11 · 蓝色 PRECIO ESPECIAL",
                "12 · 橙色 OFERTA", "13 · 绿色 GRAN OFERTA", "14 · 红色 OFERTÓN"};
        styleSpinner.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,
                isColor()?color:bw));
        styleSpinner.setSelection(isColor()?styleColor:styleBW);
        updatingStyle=false;
    }

    private interface FontSetter {void set(int n);}
    private LinearLayout slider(String caption,String key,int min,int max,int initial,FontSetter setter) {
        LinearLayout holder=new LinearLayout(this);holder.setOrientation(LinearLayout.VERTICAL);
        TextView label=text(caption+"  ·  "+initial+"%",13,true);holder.addView(label);
        SeekBar seek=new SeekBar(this);seek.setMax(max-min);seek.setProgress(Math.max(0,Math.min(max-min,initial-min)));
        holder.addView(seek);fontSeekBars.put(key,seek);seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb,int n,boolean user){
                int value=n+min; setter.set(value);label.setText(caption+"  ·  "+value+"%");
                if(preview!=null)preview.invalidate();
                if(pagePreview!=null)pagePreview.invalidate();
                prefs.edit().putInt(key,value).apply();
            }
            @Override public void onStartTrackingTouch(SeekBar s){}
            @Override public void onStopTrackingTouch(SeekBar s){}
        });
        return holder;
    }
    private void attachPreviewListener(EditText edit) {edit.addTextChangedListener(new TextWatcher(){
        @Override public void beforeTextChanged(CharSequence s,int a,int c,int f){}
        @Override public void onTextChanged(CharSequence s,int start,int before,int count){if(preview!=null)preview.invalidate();}
        @Override public void afterTextChanged(Editable e){}
    });}

    private OfferItem sampleOffer() {
        String name=trim(nameInput),brand=trim(brandInput),variety=trim(varietyInput),quantity=trim(quantityInput),old=trim(oldInput),now=trim(nowInput);
        if(name.isEmpty())name="NOMBRE DEL PRODUCTO";
        if(old.isEmpty())old="3.500";
        if(now.isEmpty())now="2.790";
        return new OfferItem(trim(barcodeInput),name,brand,variety,quantity,old,now,1,selectedStyle(),offerModeSpinner.getSelectedItemPosition()==1);
    }

    private void addOffer() {
        String name=trim(nameInput),old=normalizePrice(trim(oldInput)),now=normalizePrice(trim(nowInput));
        if(name.isEmpty()) {nameInput.setError("请输入商品名称");nameInput.requestFocus();return;}
        if(old==null || now==null) {toast("请输入正确的原价和优惠价，例如 3500 或 3.500,50");return;}
        BigDecimal o=parsePrice(old),n=parsePrice(now);
        if(o==null||n==null||o.signum()<=0||n.signum()<=0){toast("价格必须大于 0");return;}
        boolean twoFor=offerModeSpinner.getSelectedItemPosition()==1;
        BigDecimal normalTotal=twoFor ? o.multiply(BigDecimal.valueOf(2)) : o;
        if(n.compareTo(normalTotal)>0){toast(twoFor ? "两件合计特价不能超过两件原价总和" : "优惠价不能高于原价");return;}
        int copies;
        try{copies=Integer.parseInt(trim(copiesInput));}catch(Exception e){copies=0;}
        if(copies<1||copies>99){copiesInput.setError("份数为 1—99");return;}
        queue.add(new OfferItem(trim(barcodeInput),name,trim(brandInput),trim(varietyInput),trim(quantityInput),
                old,now,copies,selectedStyle(),twoFor));
        persistQueue();updateQueue();toast("已加入 " + copies + " 张，合计 " + sheetCount() + " 张");
        // Keep the latest style and font choices; reset the data for the next barcode.
        barcodeInput.setText("");nameInput.setText("");brandInput.setText("");
        varietyInput.setText("");quantityInput.setText("");oldInput.setText("");nowInput.setText("");copiesInput.setText("1");
        status.setText("可以继续扫码添加下一个商品。 ");
    }

    private int sheetCount(){int n=0;for(OfferItem i:queue)n+=i.copies;return n;}
    private void updateQueue(){
        if(queueStats==null||queueLayout==null)return;
        int count=sheetCount(),per=sheet().perPage();int pages=(count+per-1)/per;
        queueStats.setText("商品 "+queue.size()+" 种｜共 "+count+" 张｜"+sheet().name+" "+pages+" 页"+
                (count>0&&count%per!=0?"｜最后一页空 "+(per-count%per)+" 格":""));
        queueLayout.removeAllViews();
        if(pagePreview!=null)pagePreview.invalidate();
        for(int index=0;index<queue.size();index++){
            OfferItem item=queue.get(index);final int at=index;
            LinearLayout block=new LinearLayout(this);block.setPadding(dp(8),dp(8),dp(8),dp(8));
            block.setOrientation(LinearLayout.VERTICAL);
            TextView t=text((index+1)+". "+item.brand+" · "+item.name+" · "+item.variety+" · "+item.quantity+
                    "  "+OfferRenderer.money(item.now),14,true);
            block.addView(t);block.addView(text("样式 "+item.style + (item.twoFor ? " · 买2件总价" : " · 单件价") +
                    "  ·  "+OfferRenderer.money(item.before)+" → "+OfferRenderer.money(item.now),12,false));
            LinearLayout controls=row();
            TextView qty=text("份数 "+item.copies+" 张",13,true);controls.addView(qty,weight());
            Button minus=button("－",false),plus=button("＋",false),edit=button("编辑",false),delete=button("删除",false);
            controls.addView(minus);controls.addView(plus);controls.addView(edit);controls.addView(delete);block.addView(controls);
            minus.setOnClickListener(v->{if(item.copies>1){item.copies--;persistQueue();updateQueue();}});
            plus.setOnClickListener(v->{if(item.copies<99){item.copies++;persistQueue();updateQueue();}});
            edit.setOnClickListener(v->{
                barcodeInput.setText(item.barcode);nameInput.setText(item.name);brandInput.setText(item.brand);
                varietyInput.setText(item.variety);quantityInput.setText(item.quantity);
                oldInput.setText(item.before);nowInput.setText(item.now);copiesInput.setText(String.valueOf(item.copies));
                paletteSpinner.setSelection(item.style>=9?1:0);
                if(item.style>=9)styleColor=Math.max(0,Math.min(5,item.style-9));
                else styleBW=Math.max(0,Math.min(7,item.style-1));
                updateStyleList();
                offerModeSpinner.setSelection(item.twoFor ? 1 : 0);
                queue.remove(at);persistQueue();updateQueue();
                status.setText("已载入待修改商品；修改后请再次点击添加到打印清单。");
                if(scroller!=null)scroller.smoothScrollTo(0,0);
            });
            delete.setOnClickListener(v->{queue.remove(at);persistQueue();updateQueue();});
            View hr=new View(this);hr.setBackgroundColor(BORDER);
            queueLayout.addView(block);queueLayout.addView(hr,new LinearLayout.LayoutParams(-1,dp(1)));
        }
    }

    private byte[] createPdfOrNotify(){
        if(queue.isEmpty()){toast("打印清单为空，请先添加商品");return null;}
        try{return OfferRenderer.pdf(new ArrayList<>(queue),fonts.copy(),sheet(),!isColor());}
        catch(Exception ex){toast("生成 PDF 失败："+ex.getMessage());return null;}
    }
    private void savePdf(){
        pendingPdf=createPdfOrNotify();if(pendingPdf==null)return;
        Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/pdf");
        intent.putExtra(Intent.EXTRA_TITLE,"OFERTA_"+sheet().name+"_"+System.currentTimeMillis()+".pdf");
        startActivityForResult(intent,CREATE_PDF_REQUEST);
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==CREATE_PDF_REQUEST){
            if(resultCode==RESULT_OK&&data!=null&&data.getData()!=null&&pendingPdf!=null){
                final Uri dest=data.getData();final byte[] output=pendingPdf;
                io.execute(()->{
                    try(java.io.OutputStream out=getContentResolver().openOutputStream(dest)){
                        if(out==null)throw new java.io.IOException("无法打开目标文件");
                        out.write(output);out.flush();ui.post(()->toast("PDF 已保存"));
                    }catch(Exception e){ui.post(()->toast("保存失败："+e.getMessage()));}
                });
            }
            pendingPdf=null;
        }
    }
    private void printPdf(){
        byte[] pdf=createPdfOrNotify();if(pdf==null)return;
        int pageCount=(sheetCount()+sheet().perPage()-1)/sheet().perPage();
        PrintManager manager=(PrintManager)getSystemService(PRINT_SERVICE);
        if(manager==null){toast("设备没有打印服务");return;}
        OfferRenderer.Sheet size=sheet();
        PrintAttributes attrs=new PrintAttributes.Builder()
                .setMediaSize((size==OfferRenderer.Sheet.A3?
                        PrintAttributes.MediaSize.ISO_A3:PrintAttributes.MediaSize.ISO_A4).asLandscape())
                .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                .setColorMode(isColor()?PrintAttributes.COLOR_MODE_COLOR:PrintAttributes.COLOR_MODE_MONOCHROME).build();
        manager.print("OFERTA "+size.name,new PdfAdapter(pdf,pageCount,size.name),attrs);
    }
    private final class PdfAdapter extends PrintDocumentAdapter {
        private final byte[] bytes;private final int pageCount;private final String paper;
        PdfAdapter(byte[] data,int count,String paper){bytes=data;pageCount=count;this.paper=paper;}
        @Override public void onLayout(PrintAttributes oldAttrs,PrintAttributes attrs,CancellationSignal signal,
                LayoutResultCallback cb,Bundle extras){
            if(signal.isCanceled()){cb.onLayoutCancelled();return;}
            cb.onLayoutFinished(new PrintDocumentInfo.Builder("OFERTA_"+paper+".pdf")
                    .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT).setPageCount(pageCount).build(),true);
        }
        @Override public void onWrite(android.print.PageRange[] pages,ParcelFileDescriptor target,
                CancellationSignal signal,WriteResultCallback callback){
            // Android print spooler may request subsets; provide the complete document.
            io.execute(()->{
                try(FileOutputStream stream=new FileOutputStream(target.getFileDescriptor())){
                    if(signal.isCanceled()){ui.post(callback::onWriteCancelled);return;}
                    stream.write(bytes);stream.flush();
                    ui.post(()->callback.onWriteFinished(new android.print.PageRange[]{android.print.PageRange.ALL_PAGES}));
                }catch(Exception e){ui.post(()->callback.onWriteFailed(e.getMessage()));}
            });
        }
    }

    private void scanBarcode(){
        GmsBarcodeScannerOptions opts=new GmsBarcodeScannerOptions.Builder()
                .setBarcodeFormats(Barcode.FORMAT_EAN_13,Barcode.FORMAT_EAN_8,
                        Barcode.FORMAT_UPC_A,Barcode.FORMAT_UPC_E,Barcode.FORMAT_CODE_128)
                .enableAutoZoom().build();
        GmsBarcodeScanner scanner=GmsBarcodeScanning.getClient(this,opts);
        scanner.startScan().addOnSuccessListener(barcode->{
            String raw=barcode.getRawValue();
            if(raw!=null&&!raw.isEmpty()){barcodeInput.setText(raw);fetchProduct();}
        }).addOnFailureListener(e->toast("扫码失败，请确认 Google Play 服务正常，或手动输入条码："+e.getMessage()));
    }
    private void fetchProduct(){
        final String code=trim(barcodeInput);
        if(!code.matches("\\d{8,14}")){barcodeInput.setError("请输入 8—14 位数字条形码");return;}
        String cached=prefs.getString("product_"+code,null);
        if(cached!=null){try{applyProduct(new JSONObject(cached));status.setText("已使用本地商品信息，可手动修改。 ");return;}
            catch(Exception ignored){} }
        long now=SystemClock.elapsedRealtime();
        if(now-lastNetworkAt<4100){status.setText("请稍后再查，防止超过免费接口调用限制。 ");return;}
        lastNetworkAt=now;
        status.setText("正在查询 Open Food Facts...");
        io.execute(()->{
            HttpURLConnection c=null;
            try {
                // OFF API v3: no key; use a dedicated User-Agent. Add real contact in production.
                URL u=new URL("https://world.openfoodfacts.org/api/v3/product/"+code+
                        "?fields=product_name,product_name_es,generic_name,generic_name_es,brands,quantity&lc=es&cc=ar");
                c=(HttpURLConnection)u.openConnection();c.setRequestMethod("GET");
                c.setRequestProperty("User-Agent","OfertaA4/1.0 (Android personal supermarket label app)");
                c.setRequestProperty("Accept","application/json");
                c.setConnectTimeout(10000);c.setReadTimeout(12000);
                int http=c.getResponseCode();
                if(http==404){ui.post(()->status.setText("商品库中没有该条码，可以手动填写名称、品牌。"));return;}
                if(http==429||http==503){ui.post(()->status.setText("Open Food Facts 查询受限，请稍后重试或手动输入。"));return;}
                if(http!=200)throw new Exception("HTTP "+http);
                StringBuilder json=new StringBuilder();
                try(InputStream in=c.getInputStream();BufferedReader reader=new BufferedReader(new InputStreamReader(in,java.nio.charset.StandardCharsets.UTF_8))){
                    String line;while((line=reader.readLine())!=null)json.append(line);
                }
                JSONObject root=new JSONObject(json.toString());
                JSONObject product=root.optJSONObject("product");
                if(product==null||product.length()==0){ui.post(()->status.setText("商品没有找到，可直接手动填写。"));return;}
                prefs.edit().putString("product_"+code,product.toString()).apply();
                ui.post(()->{if(code.equals(trim(barcodeInput))){applyProduct(product);status.setText("查询成功。请确认商品规格并输入原价、优惠价。 ");}});
            } catch(Exception ex){ui.post(()->status.setText("网络查询失败（"+ex.getMessage()+"），可以手动填写。"));}
            finally {if(c!=null)c.disconnect();}
        });
    }
    private void applyProduct(JSONObject data){
        String raw=data.optString("product_name_es","").trim();
        if(raw.isEmpty())raw=data.optString("product_name","").trim();
        String generic=data.optString("generic_name_es","").trim();
        if(generic.isEmpty())generic=data.optString("generic_name","").trim();
        String brand=data.optString("brands","").trim();
        String quantity=data.optString("quantity","").trim();
        String variety=detectExplicitVariety(raw+" "+generic);
        // A vintage year is shown only if it appears in actual product data.
        if(isWineVariety(variety)) {
            java.util.regex.Matcher year=java.util.regex.Pattern.compile("(?<![0-9])20[0-9]{2}(?![0-9])")
                    .matcher(raw+" "+generic);
            if(year.find())variety=variety+" "+year.group();
        }
        String name=raw;
        // Remove only explicitly present brand, quantity or recognized variant suffixes.
        // Never invent a flavor or vintage: users may enter/check them manually.
        if(!brand.isEmpty()) name=removePrefixIgnoreCase(name,brand);
        if(!quantity.isEmpty())name=removeLiteralIgnoreCase(name,quantity);
        if(!variety.isEmpty()) {
            name=removeLiteralIgnoreCase(name,variety);
            // The year may be separate from the grape variety inside the source name.
            String grape=variety.replaceFirst("\\s+20[0-9]{2}$","");
            if(!grape.equals(variety))name=removeLiteralIgnoreCase(name,grape);
        }
        name=name.replaceAll("(?iu)\\b(SABOR|VARIEDAD)\\s*$","").trim();
        name=name.replaceAll("^[\\s,;/\\-]+|[\\s,;/\\-]+$","").trim();
        if(name.isEmpty())name=generic.isEmpty()?raw:generic;
        // Always clear the previous barcode's details, even when the new record is partial.
        // This prevents a previous strawberry yogurt or Malbec variant from carrying over.
        nameInput.setText(name);
        brandInput.setText(brand);
        quantityInput.setText(quantity);
        varietyInput.setText(variety);
        if(name.isEmpty() && brand.isEmpty())status.setText("商品信息不完整，请手动填写。 ");
    }
    private static String removePrefixIgnoreCase(String text,String part){
        String s=text.trim(),pre=part.trim();
        if(!pre.isEmpty()&&s.toLowerCase(Locale.ROOT).startsWith(pre.toLowerCase(Locale.ROOT)))
            return s.substring(pre.length()).replaceFirst("^[\\s,;:\\-]+","").trim();
        return s;
    }
    private static String removeLiteralIgnoreCase(String s,String part){
        if(part.trim().isEmpty())return s;
        return s.replaceFirst("(?iu)"+java.util.regex.Pattern.quote(part),"").trim();
    }
    private static boolean isWineVariety(String v) {
        return v.equals("MALBEC")||v.equals("CABERNET SAUVIGNON")||v.equals("CABERNET FRANC")||
                v.equals("MERLOT")||v.equals("CHARDONNAY")||v.equals("SAUVIGNON BLANC")||
                v.equals("PINOT NOIR")||v.equals("SYRAH")||v.equals("TEMPRANILLO");
    }
    /** Detect only variants explicitly spelled in the product database description. */
    private static String detectExplicitVariety(String name){
        String normalized=name.toUpperCase(Locale.ROOT);
        String[] known={"CABERNET SAUVIGNON","CABERNET FRANC","SAUVIGNON BLANC","PINOT NOIR",
            "AMBER LAGER","CHARDONNAY","TEMPRANILLO","FRUTILLA","VAINILLA","ARÁNDANOS",
            "ARANDANOS","FRAMBUESA","CHOCOLATE","DURAZNO","MANZANA","NARANJA","POMELO",
            "MALBEC","MERLOT","SYRAH","CHENIN","ROSADO","FRUTOS ROJOS","NATURAL",
            "FRESA","BANANA","MANGO","LIMÓN","LIMON","COCO","RUBIA","NEGRA","ROJA","IPA"};
        for(String v:known) {
            java.util.regex.Matcher m=java.util.regex.Pattern.compile(
                "(?iu)(?<![\\p{L}])"+java.util.regex.Pattern.quote(v)+"(?![\\p{L}])").matcher(normalized);
            if(m.find())return v;
        }
        return "";
    }

    private void persistQueue(){
        JSONArray arr=new JSONArray();
        try{for(OfferItem item:queue){JSONObject j=new JSONObject();
            j.put("code",item.barcode);j.put("name",item.name);j.put("brand",item.brand);
            j.put("old",item.before);j.put("now",item.now);j.put("copies",item.copies);
            j.put("style",item.style);j.put("twoFor",item.twoFor);
            j.put("variety",item.variety);j.put("quantity",item.quantity);arr.put(j);
        }}catch(Exception ignored){}
        prefs.edit().putString("queue",arr.toString()).apply();
    }
    private void loadQueue(){
        try {JSONArray arr=new JSONArray(prefs.getString("queue","[]"));
            for(int i=0;i<arr.length();i++){JSONObject j=arr.getJSONObject(i);
                queue.add(new OfferItem(j.optString("code"),j.optString("name"),j.optString("brand"),
                        j.optString("variety"),j.optString("quantity"),j.optString("old"),j.optString("now"),
                        Math.max(1,Math.min(99,j.optInt("copies",1))),
                        Math.max(1,Math.min(14,j.optInt("style",1))),j.optBoolean("twoFor",false)));
            }
        }catch(Exception e){queue.clear();}
    }

    private static BigDecimal parsePrice(String original){
        if(original==null)return null;
        String v=original.replace("$","").replaceAll("(?i)ars","").replace(" ","").trim();
        if(!v.matches("[0-9][0-9.,]*"))return null;
        int comma=v.lastIndexOf(','),dot=v.lastIndexOf('.');
        if(comma>=0){v=v.replace(".","").replace(',','.');}
        else if(dot>=0){
            // Argentine prices like 3.500: a dot followed by exactly 3 digits is a grouping separator.
            if(v.length()-dot-1==3)v=v.replace(".","");
            else if(v.indexOf('.')!=dot)v=v.replace(".","");
        }
        try{return new BigDecimal(v).setScale(2,RoundingMode.HALF_UP);}catch(Exception e){return null;}
    }
    private static String normalizePrice(String original){
        BigDecimal v=parsePrice(original);if(v==null||v.signum()<=0)return null;
        DecimalFormatSymbols syms=new DecimalFormatSymbols(new Locale("es","AR"));
        syms.setGroupingSeparator('.');syms.setDecimalSeparator(',');
        DecimalFormat format=new DecimalFormat("#,##0.##",syms);
        boolean decimals=original.contains(",") ||
                (original.matches(".*\\.\\d{1,2}$") && !original.contains(","));
        format.setMinimumFractionDigits(decimals?2:0);format.setMaximumFractionDigits(2);
        return format.format(v);
    }

    private int dp(float d){return (int)(d*getResources().getDisplayMetrics().density+0.5f);}
    private static String trim(EditText edit){return edit.getText().toString().trim();}
    private LinearLayout row(){LinearLayout r=new LinearLayout(this);r.setGravity(Gravity.CENTER_VERTICAL);
        r.setOrientation(LinearLayout.HORIZONTAL);return r;}
    private LinearLayout.LayoutParams weight(){return new LinearLayout.LayoutParams(0,-2,1f);}
    private TextView text(String value,int size,boolean bold){TextView tv=new TextView(this);tv.setText(value);
        tv.setTextColor(INK);tv.setTextSize(size);tv.setPadding(dp(3),dp(4),dp(3),dp(4));
        if(bold)tv.setTypeface(android.graphics.Typeface.DEFAULT,android.graphics.Typeface.BOLD);
        return tv;}
    private TextView section(String value){TextView tv=text(value,18,true);tv.setPadding(dp(0),dp(8),0,dp(8));return tv;}
    private EditText field(String hint,int inputType){EditText et=new EditText(this);et.setHint(hint);
        et.setSingleLine(true);et.setTextSize(17);et.setTextColor(INK);et.setInputType(inputType);
        et.setPadding(dp(7),dp(8),dp(7),dp(8));
        et.setLayoutParams(new LinearLayout.LayoutParams(-1,-2));return et;}
    private Button button(String caption,boolean filled){Button b=new Button(this);b.setText(caption);
        b.setTextSize(13);b.setAllCaps(false);
        b.setTextColor(filled?Color.WHITE:Color.BLACK);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(filled?0xff111111:0xffeeeeee));
        b.setMinimumHeight(dp(44));return b;}
    private void space(LinearLayout root,int px){View v=new View(this);root.addView(v,new LinearLayout.LayoutParams(1,dp(px)));}
    private void toast(String value){Toast.makeText(this,value,Toast.LENGTH_LONG).show();}
    private final class PreviewView extends View {
        private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
        PreviewView(){super(MainActivity.this);setBackgroundColor(0xfff4f4f4);}
        @Override protected void onDraw(Canvas canvas){super.onDraw(canvas);
            float sx=(getWidth()-dp(12))/OfferRenderer.CELL_W;
            float sy=(getHeight()-dp(12))/OfferRenderer.CELL_H;
            float s=Math.min(sx,sy);
            float dx=(getWidth()-OfferRenderer.CELL_W*s)/2f;
            float dy=(getHeight()-OfferRenderer.CELL_H*s)/2f;
            canvas.save();canvas.translate(dx,dy);canvas.scale(s,s);
            OfferRenderer.drawOffer(canvas,sampleOffer(),fonts,!isColor());
            paint.setColor(Color.BLACK);paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(0.8f);
            canvas.drawRect(0,0,OfferRenderer.CELL_W,OfferRenderer.CELL_H,paint);
            paint.setStyle(Paint.Style.FILL);canvas.restore();
        }
    }
    private final class PagePreviewView extends View {
        private final Paint border=new Paint(Paint.ANTI_ALIAS_FLAG);
        PagePreviewView(){super(MainActivity.this);setBackgroundColor(0xfff4f4f4);}
        @Override protected void onDraw(Canvas canvas){super.onDraw(canvas);
            OfferRenderer.Sheet sheet=sheet();
            float sx=(getWidth()-dp(12))/(float)sheet.pageW;
            float sy=(getHeight()-dp(12))/(float)sheet.pageH;
            float s=Math.min(sx,sy);
            float dx=(getWidth()-sheet.pageW*s)/2f;
            float dy=(getHeight()-sheet.pageH*s)/2f;
            canvas.save();canvas.translate(dx,dy);canvas.scale(s,s);
            OfferRenderer.drawPage(canvas,OfferRenderer.expand(queue),0,fonts,sheet,!isColor());
            border.setColor(Color.BLACK);border.setStyle(Paint.Style.STROKE);border.setStrokeWidth(.8f);
            canvas.drawRect(0,0,sheet.pageW,sheet.pageH,border);
            border.setStyle(Paint.Style.FILL);canvas.restore();
        }
    }
    @Override protected void onDestroy(){io.shutdown();super.onDestroy();}
}
