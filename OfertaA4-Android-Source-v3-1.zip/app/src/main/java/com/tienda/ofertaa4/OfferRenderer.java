package com.tienda.ofertaa4;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.pdf.PdfDocument;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Vector PDF and on-screen previews share exactly the same renderer and layout. */
public final class OfferRenderer {
    /** Internal aspect ratio: every label is a WIDE 420:297 rectangle. */
    public static final float CELL_W = 420f;
    public static final float CELL_H = 297f;
    private static final Typeface HEAVY = Typeface.create("sans-serif-condensed-black", Typeface.BOLD);
    private static final Typeface BOLD = Typeface.create("sans-serif-condensed", Typeface.BOLD);
    private static final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.SUBPIXEL_TEXT_FLAG);

    public enum Sheet {
        A4("A4", 842, 595, 2, 2, 148.5f, 105.0f),
        A3("A3", 1191, 842, 3, 3, 140.0f, 99.0f);
        public final String name;
        public final int pageW, pageH, cols, rows;
        public final float labelWidthMm, labelHeightMm;
        Sheet(String name, int pageW, int pageH, int cols, int rows, float w, float h) {
            this.name=name;this.pageW=pageW;this.pageH=pageH;this.cols=cols;this.rows=rows;
            this.labelWidthMm=w;this.labelHeightMm=h;
        }
        public int perPage(){return cols*rows;}
        public float physicalCellW(){return (float)pageW/cols;}
        public float physicalCellH(){return (float)pageH/rows;}
    }

    public static final class Fonts {
        public int headline=100, brand=100, product=100, original=100, special=100;
        public Fonts copy() {
            Fonts f=new Fonts(); f.headline=headline;f.brand=brand;f.product=product;
            f.original=original;f.special=special;return f;
        }
    }

    public static List<OfferItem> expand(List<OfferItem> items) {
        List<OfferItem> all=new ArrayList<>();
        for(OfferItem item:items) for(int i=0;i<Math.max(0,Math.min(99,item.copies));i++) all.add(item);
        return all;
    }
    public static int pages(List<OfferItem> expanded, Sheet sheet) {
        return (expanded.size()+sheet.perPage()-1)/sheet.perPage();
    }
    public static byte[] pdf(List<OfferItem> items,Fonts fonts,Sheet sheet,boolean monochrome) throws IOException {
        List<OfferItem> all=expand(items);
        if(all.isEmpty()) throw new IOException("请先加入商品");
        PdfDocument doc=new PdfDocument();
        try {
            for(int index=0;index<pages(all,sheet);index++) {
                PdfDocument.PageInfo info=new PdfDocument.PageInfo.Builder(sheet.pageW,sheet.pageH,index+1).create();
                PdfDocument.Page page=doc.startPage(info);
                drawPage(page.getCanvas(),all,index,fonts,sheet,monochrome);
                doc.finishPage(page);
            }
            ByteArrayOutputStream bytes=new ByteArrayOutputStream();doc.writeTo(bytes);return bytes.toByteArray();
        } finally { doc.close(); }
    }

    public static void drawPage(Canvas c,List<OfferItem> expanded,int pageIndex,Fonts fonts,
                                Sheet sheet,boolean monochrome) {
        c.drawColor(Color.WHITE);
        float cw=sheet.physicalCellW(),ch=sheet.physicalCellH();
        for(int i=0;i<sheet.perPage();i++) {
            int index=pageIndex*sheet.perPage()+i;
            if(index>=expanded.size()) continue;
            c.save();
            float x=(i%sheet.cols)*cw,y=(i/sheet.cols)*ch;
            c.translate(x,y);
            c.clipRect(0,0,cw,ch);
            // A3 labels are naturally slightly smaller than their A4 counterparts.
            c.scale(cw/CELL_W,ch/CELL_H);
            drawOffer(c,expanded.get(index),fonts,monochrome);
            c.restore();
        }
        p.reset();p.setAntiAlias(true);p.setColor(Color.DKGRAY);p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(.8f);p.setPathEffect(new DashPathEffect(new float[]{5f,4f},0));
        for(int col=1;col<sheet.cols;col++) c.drawLine(cw*col,0,cw*col,sheet.pageH,p);
        for(int row=1;row<sheet.rows;row++) c.drawLine(0,ch*row,sheet.pageW,ch*row,p);
        p.setPathEffect(null);p.setStyle(Paint.Style.FILL);
    }

    /** Draw one 420×297 label. Monochrome headings: solid black on blank white paper. */
    public static void drawOffer(Canvas c,OfferItem item,Fonts fonts,boolean monochrome) {
        c.save();c.clipRect(0,0,CELL_W,CELL_H);c.drawColor(Color.WHITE);
        int style=Math.max(1,Math.min(14,item.style));
        boolean colored=style>=9&&!monochrome;
        int accent=colored?accentFor(style):Color.BLACK;
        int textAccent=colored && style==10 ? 0xffb21924 : accent;
        // Monochrome MUST NOT print a black header band or any headline frame.
        // Keep the colored header artwork only for color printing.
        boolean darkBanner=colored;
        boolean border=colored && (style==11||style==13);
        final float left=11f,right=CELL_W-11f,mid=CELL_W/2f;
        if(border) {
            p.reset();p.setAntiAlias(true);p.setColor(accent);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1.6f);
            c.drawRect(5f,5f,CELL_W-5f,CELL_H-5f,p);p.setStyle(Paint.Style.FILL);
        }
        if(darkBanner) {
            int bandColor=colored?(style==10?0xffffde22:accent):Color.BLACK;
            p.reset();p.setAntiAlias(true);p.setColor(bandColor);
            if(style==8||style==12) c.drawRoundRect(new RectF(left,8,right,67),6f,6f,p);
            else c.drawRect(left,8,right,67,p);
            label(c,heading(style),mid,52f,49f*fonts.headline/100f,381f,HEAVY,
                    style==10?Color.BLACK:Color.WHITE);
        } else {
            // White paper behind OFERTA / PRECIO ESPECIAL / REBAJA, without
            // the old black rectangle. Large, heavy black ink only.
            label(c,heading(style),mid,57f,56f*fonts.headline/100f,392f,HEAVY,Color.BLACK);
        }
        // Four fields are always treated separately, so varieties do not get lost.
        String brand=upper(item.brand);
        String name=upper(item.name);
        String variety=upper(item.variety);
        String quantity=upper(item.quantity);
        if(!brand.isEmpty()) label(c,brand,mid,89f,21f*fonts.brand/100f,385f,HEAVY,Color.BLACK);
        if(name.isEmpty()) name="NOMBRE DEL PRODUCTO";
        // Split very long names over at most two lines without stealing the variety line.
        float maxNameSize=29f*fonts.product/100f;
        if(widthOf(name,maxNameSize,HEAVY)>392f && name.length()>15) {
            String[] lines=splitName(name);
            label(c,lines[0],mid,112f,Math.min(28f,maxNameSize),387f,HEAVY,Color.BLACK);
            label(c,lines[1],mid,134f,Math.min(26f,maxNameSize),387f,HEAVY,Color.BLACK);
        } else label(c,name,mid,126f,Math.min(33f,maxNameSize),387f,HEAVY,Color.BLACK);
        if(!variety.isEmpty()) label(c,"VARIEDAD / SABOR: "+variety,mid,154f,
                21f*fonts.product/100f,387f,HEAVY,colored?textAccent:Color.BLACK);
        if(!quantity.isEmpty()) label(c,"CONTENIDO: "+quantity,mid,173f,17f,387f,BOLD,Color.BLACK);
        String beforePrefix=item.twoFor?"ANTES C/U  ":"ANTES  ";
        drawCrossed(c,mid,195f,beforePrefix,money(item.before),
                Math.min(24f,20f*fonts.original/100f),384f);
        label(c,item.twoFor?"LLEVANDO 2 UNIDADES · TOTAL":"AHORA",mid,215f,
                item.twoFor?17f:20f,387f,HEAVY,Color.BLACK);
        String price=money(item.now);
        float wanted=Math.min(190f,120f*fonts.special/100f);
        float widthFit=fit(price,wanted,390f,HEAVY);
        float availableHeight=72f; // price glyphs must not overlap the label above
        float heightFit=fontForHeight(price,availableHeight);
        float font=Math.max(9f,Math.min(widthFit,heightFit));
        label(c,price,mid,290f,font,390f,HEAVY,colored?textAccent:Color.BLACK);
        c.restore();
    }

    private static int accentFor(int style) {
        switch(style) {
            case 9: return 0xffd51c24; // traditional Argentine sale red
            case 10: return 0xffe5a800; // yellow sale label
            case 11: return 0xff184ca1; // blue special price
            case 12: return 0xffe66a00;
            case 13: return 0xff08764a;
            case 14: return 0xffb51233;
            default: return Color.BLACK;
        }
    }
    public static boolean containsColor(List<OfferItem> queue) {
        for(OfferItem item:queue) if(item.style>=9) return true;
        return false;
    }
    public static String heading(int style) {
        switch(style) {
            case 2:case 10:return "¡SUPER OFERTA!";
            case 3:case 11:return "PRECIO ESPECIAL";
            case 4:case 12:return "OFERTA";
            case 5:case 13:return "GRAN OFERTA";
            case 6:return "REBAJA";
            case 7:return "¡OFERTÓN!";
            case 8:return "OFERTA DEL DÍA";
            case 14:return "¡OFERTÓN!";
            default:return "OFERTA";
        }
    }
    public static String money(String value) {
        String s=value==null?"":value.trim();
        if(s.isEmpty())return "$ 0";
        if(s.startsWith("$")||s.startsWith("ARS"))return s;
        return "$ "+s;
    }
    private static String upper(String s){return s==null?"":s.trim().toUpperCase(Locale.ROOT);}
    private static void label(Canvas c,String title,float x,float y,float size,float max,Typeface type,int color) {
        p.reset();p.setAntiAlias(true);p.setSubpixelText(true);p.setTypeface(type);
        p.setFakeBoldText(true);p.setTextAlign(Paint.Align.CENTER);p.setColor(color);
        p.setTextSize(Math.max(6.5f,fit(title,size,max,type)));c.drawText(title,x,y,p);
    }
    private static float widthOf(String s,float size,Typeface face) {
        p.reset();p.setTypeface(face);p.setFakeBoldText(true);p.setTextSize(size);
        return p.measureText(s);
    }
    private static float fit(String s,float size,float max,Typeface face) {
        float width=widthOf(s,size,face);
        return width>max&&width>0?size*max/width:size;
    }
    private static float fontForHeight(String s,float maxPixels) {
        p.reset();p.setTypeface(HEAVY);p.setFakeBoldText(true);p.setTextSize(100f);
        Rect bounds=new Rect();p.getTextBounds(s,0,s.length(),bounds);
        return maxPixels*100f/Math.max(1f,-bounds.top);
    }
    private static void drawCrossed(Canvas c,float x,float y,String prefix,String price,float requested,float maxWidth) {
        p.reset();p.setAntiAlias(true);p.setTypeface(BOLD);p.setFakeBoldText(true);
        p.setTextSize(requested);p.setColor(Color.BLACK);p.setTextAlign(Paint.Align.LEFT);
        String all=prefix+price;
        float total=p.measureText(all);
        if(total>maxWidth){p.setTextSize(requested*maxWidth/total);total=p.measureText(all);}
        float start=x-total/2f;
        c.drawText(all,start,y,p);
        float prefixW=p.measureText(prefix);
        line(c,start+prefixW,y-7f,start+total,y-11f,1.8f,Color.BLACK);
    }
    private static void line(Canvas c,float x1,float y1,float x2,float y2,float width,int color) {
        p.reset();p.setAntiAlias(true);p.setColor(color);p.setStrokeWidth(width);p.setStyle(Paint.Style.STROKE);
        c.drawLine(x1,y1,x2,y2,p);p.setStyle(Paint.Style.FILL);
    }
    private static String[] splitName(String str) {
        String[] words=str.trim().split("\\s+");
        if(words.length<2) {
            int half=str.length()/2;return new String[]{str.substring(0,half),str.substring(half)};
        }
        String first="",second="";int delta=Integer.MAX_VALUE;
        for(int i=1;i<words.length;i++) {
            StringBuilder a=new StringBuilder(),b=new StringBuilder();
            for(int j=0;j<words.length;j++) {StringBuilder out=j<i?a:b;if(out.length()>0)out.append(' ');out.append(words[j]);}
            int current=Math.abs(a.length()-b.length());
            if(current<delta){first=a.toString();second=b.toString();delta=current;}
        }
        return new String[]{first,second};
    }
    private OfferRenderer(){}
}
