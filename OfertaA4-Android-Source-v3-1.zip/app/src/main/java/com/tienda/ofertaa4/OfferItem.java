package com.tienda.ofertaa4;

/** A product label. Each printed copy is one paper label, not one purchased unit. */
public final class OfferItem {
    public final String barcode;
    public final String name;
    public final String brand;
    public final String variety;
    public final String quantity;
    public final String before;
    public final String now;
    /** 1..8 black-and-white designs; 9..14 color designs. */
    public final int style;
    /** Two-for promotion: before is per item; now is total for two items. */
    public final boolean twoFor;
    public int copies;

    public OfferItem(String barcode, String name, String brand, String variety, String quantity,
                     String before, String now, int copies, int style, boolean twoFor) {
        this.barcode = safe(barcode);
        this.name = safe(name);
        this.brand = safe(brand);
        this.variety = safe(variety);
        this.quantity = safe(quantity);
        this.before = safe(before);
        this.now = safe(now);
        this.copies = copies;
        this.style = style;
        this.twoFor = twoFor;
    }

    /** Compatibility with saved labels from version 1.1. */
    public OfferItem(String barcode, String name, String brand, String before, String now,
                     int copies, int style, boolean twoFor) {
        this(barcode, name, brand, "", "", before, now, copies, style, twoFor);
    }

    private static String safe(String value) { return value == null ? "" : value.trim(); }
}
